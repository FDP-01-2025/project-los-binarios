#include "resource/archery.h"
#include "resource/casinoGame.h"
#include "resource/chubby.h"
#include "resource/finalBattle.h"
#include "resource/firstCasinoGamept1.h"
#include "resource/firstCasinoGamept2.h"
#include "resource/firstCasinoGamept3.h"
#include "resource/history.h"
#include "resource/menu.h"
#include "resource/prologue.h"
#include "resource/race.h"
#include "resource/secondCasinoGamept1.h"
#include "resource/secondCasinoGamept2.h"
#include "resource/sleep.h"
#include "resource/softia.h"
#include "resource/statues.h"
#include "resource/thirdsCasinoGamept1.h"
#include "resource/thirdsCasinoGamept2.h"
#include "resource/thirdsCasinoGamept3.h"

int main() {
    history();

    return 0;
}
